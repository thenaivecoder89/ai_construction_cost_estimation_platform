-- OWNER EXECUTION ONLY. Review docs/BACKEND_DEPLOYMENT_NOTES.md first.
-- Additive migration. No evidence is deleted, relabelled or renumbered.
BEGIN;
SET LOCAL lock_timeout = '5s';
SET LOCAL statement_timeout = '120s';

-- The historical inventory may have been recreated by pandas.to_sql(replace).
-- Fail safely on ambiguous identities; owner must investigate, never auto-deduplicate.
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM build_document_inventory WHERE document_id IS NULL OR source_group IS NULL OR corpus_pack IS NULL OR relative_path IS NULL) THEN
    RAISE EXCEPTION 'Inventory has null identities; inspect and resolve before migration';
  END IF;
  IF EXISTS (SELECT document_id FROM build_document_inventory GROUP BY document_id HAVING count(*) > 1) THEN
    RAISE EXCEPTION 'Inventory has duplicate document IDs; owner reconciliation required';
  END IF;
  IF EXISTS (SELECT source_group, corpus_pack, relative_path FROM build_document_inventory GROUP BY source_group, corpus_pack, relative_path HAVING count(*) > 1) THEN
    RAISE EXCEPTION 'Inventory has duplicate source identities; owner reconciliation required';
  END IF;
  IF EXISTS (SELECT 1 FROM build_document_inventory i JOIN documents d USING(document_id)
             WHERE i.source_group IS DISTINCT FROM d.corpus_zone OR i.corpus_pack IS DISTINCT FROM d.corpus_pack
                OR i.relative_path IS DISTINCT FROM d.relative_path) THEN
    RAISE EXCEPTION 'Historical inventory/document identities disagree; owner reconciliation required';
  END IF;
  IF EXISTS (SELECT 1 FROM chunks c JOIN documents d USING(document_id)
             WHERE c.corpus_zone IS DISTINCT FROM d.corpus_zone OR c.corpus_pack IS DISTINCT FROM d.corpus_pack) THEN
    RAISE EXCEPTION 'Historical chunk/document project attribution disagrees; owner reconciliation required';
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS project_registry (
  project_id TEXT PRIMARY KEY CHECK (project_id ~ '^[A-Za-z0-9][A-Za-z0-9_-]{0,79}$'),
  display_name TEXT NOT NULL,
  firebase_prefix TEXT NOT NULL UNIQUE,
  project_kind TEXT NOT NULL DEFAULT 'client' CHECK (project_kind IN ('client','legacy_client')),
  registered_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  upload_status TEXT NOT NULL DEFAULT 'registered',
  processing_status TEXT NOT NULL DEFAULT 'not_started',
  stage_status JSONB NOT NULL DEFAULT '{}'::jsonb,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  legacy_mapping JSONB NOT NULL DEFAULT '{}'::jsonb,
  CHECK ((project_kind='client' AND firebase_prefix='projects/' || project_id || '/')
      OR (project_kind='legacy_client' AND firebase_prefix LIKE 'client_data/%'))
);

CREATE TABLE IF NOT EXISTS project_files (
  project_id TEXT NOT NULL REFERENCES project_registry(project_id),
  relative_path TEXT NOT NULL,
  original_filename TEXT NOT NULL,
  firebase_uri TEXT NOT NULL UNIQUE,
  firebase_generation TEXT,
  sha256_checksum TEXT NOT NULL,
  file_size_bytes BIGINT NOT NULL CHECK (file_size_bytes >= 0),
  content_type TEXT,
  upload_status TEXT NOT NULL DEFAULT 'pending',
  error_message TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (project_id, relative_path)
);

ALTER TABLE build_document_inventory ADD COLUMN IF NOT EXISTS firebase_uri TEXT;
ALTER TABLE build_document_inventory ADD COLUMN IF NOT EXISTS firebase_generation TEXT;
ALTER TABLE build_document_inventory ADD COLUMN IF NOT EXISTS source_relative_path TEXT;
ALTER TABLE build_document_inventory ADD COLUMN IF NOT EXISTS is_active BOOLEAN NOT NULL DEFAULT TRUE;
CREATE UNIQUE INDEX IF NOT EXISTS uq_inventory_document_id ON build_document_inventory(document_id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_inventory_source ON build_document_inventory(source_group, corpus_pack, relative_path);
CREATE INDEX IF NOT EXISTS idx_inventory_project_active ON build_document_inventory(source_group, corpus_pack, is_active);

ALTER TABLE documents ADD COLUMN IF NOT EXISTS firebase_uri TEXT;
ALTER TABLE documents ADD COLUMN IF NOT EXISTS source_relative_path TEXT;
ALTER TABLE documents ADD COLUMN IF NOT EXISTS extracted_checksum_sha256 TEXT;
ALTER TABLE documents ADD COLUMN IF NOT EXISTS extraction_revision BIGINT NOT NULL DEFAULT 0;
ALTER TABLE documents ADD COLUMN IF NOT EXISTS chunked_revision BIGINT;
CREATE INDEX IF NOT EXISTS idx_documents_project_extraction ON documents(corpus_zone, corpus_pack, extraction_status);
CREATE INDEX IF NOT EXISTS idx_chunks_project_embedding ON chunks(corpus_zone, corpus_pack) WHERE embedding IS NULL;

CREATE TABLE IF NOT EXISTS pipeline_jobs (
  job_id TEXT PRIMARY KEY,
  project_id TEXT REFERENCES project_registry(project_id),
  lock_scope TEXT NOT NULL,
  operation TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('queued','running','completed','partial','failed','interrupted')),
  parameters JSONB NOT NULL DEFAULT '{}'::jsonb,
  result JSONB,
  error_message TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_pipeline_jobs_active ON pipeline_jobs(lock_scope) WHERE status IN ('queued','running');
CREATE INDEX IF NOT EXISTS idx_pipeline_jobs_project ON pipeline_jobs(project_id, created_at DESC);

-- Known client project. No evidence rows are touched.
INSERT INTO project_registry(project_id, display_name, firebase_prefix, upload_status, legacy_mapping)
VALUES ('private_villa_001','Private Villa 001','projects/private_villa_001/','legacy',
        '{"inventory_relative_prefix":"client_data/private_villa_001/","review_existing_paths":true}')
ON CONFLICT (project_id) DO NOTHING;

-- The repo-name identifier was a flat client-data alias, NOT the shared corpus.
-- Its historical actual storage cannot be inferred safely from source alone.
-- Inactive until the OWNER verifies client_data/ and the inventory path mapping.
INSERT INTO project_registry(project_id, display_name, firebase_prefix, project_kind,
                             upload_status, processing_status, is_active, legacy_mapping)
VALUES ('ai_construction_cost_estimation_platform','Legacy client evidence (mapping review required)',
        'client_data/','legacy_client','legacy','mapping_review_required',FALSE,
        '{"inventory_relative_prefix":"client_data/","requires_owner_verification":true}')
ON CONFLICT (project_id) DO NOTHING;
COMMIT;
